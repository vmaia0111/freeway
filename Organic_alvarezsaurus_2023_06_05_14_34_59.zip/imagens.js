let imagemDaEstrada;
let imagemAtor
let ImagemCarro

function preload(){
  imagemDaEstrada = loadImage('imagens/estrada.png');
  imagemAtor = loadImage('imagens/ator-1.png');
  imagemCarro1 = loadImage('imagens/carro-1.png')
  imagemCarro2 = loadImage('imagens/carro-2.png')
  imagemCarro3 = loadImage('imagens/carro-3.png')
  imagemCarros = [imagemCarro1, imagemCarro2, imagemCarro3];
}